import footer from "./footerlogic.js"

let lower=document.getElementById("bigcontainer")
lower.innerHTML=footer()