function footer(){
    return `   <div id="foocontainer">
        <!-- <----subscript--------------  -->
        <div class="subscribe">
          <div id="form">
            <form
              method="post"
              action="/contact#contact_form"
              id="contact_form"
              accept-charset="UTF-8"
              class="contact-form"
              onsubmit='window.Shopify.recaptchaV3.addToken(this, "customer"); return false;'
            >
           
              <label for="mail-footer" class="subscribe__label"
                >Your Daily Dose of Beauty:</label
              >
              <div class="subscribe-mail">
            
                
                <input
                  type="email"
                  aria-label="Email"
                  id="mail-footer"
                  class="subscribe__field"
                  name="contact[email]"
                  required=""
                  placeholder="Enter your email address..."
                  role="alert"
                  aria-live="assertive"
                />
                <input
                  id="submit-footer"
                  type="submit"
                  class="newsletter"
                  value="subscribe"
                  data-klaviyo-list-id="Qc7Qac"
                  data-klaviyo-form-id="Qf6awa"
                />
              </div>
            </form>
          </div>
          <!-- <=======> -->
          <div id="socials">
            <div id="image">
              <img
                src="https://cdn.shopify.com/s/files/1/0637/6147/files/Credo_Logo_White_web_1_120x.png?v=1636718851"
              />
            </div>
            <div id="image1">
              <img
                src="https://cdn.shopify.com/s/files/1/0637/6147/files/Badge-reviewedby-black_271a3720-5df8-4118-a01b-d4d85bf20b7f_120x.png?v=1636718743"
              />
            </div>
          </div>
        </div>
  
        <!-- <----------------comondiv-------------------------------------->
  
        <div id="commondiv">
          <div id="seconddiv">
            <!-- <------ABOUTDIV---------->
            <div class="widgets">
              <div class="widget" style="max-width: 145px">
                <h2>About Us</h2>
  
                <ul id="footul"> 
                  <li id="footlist">
                    <a
                      href="/pages/about"
                      data-ga="Why Credo"
                      data-ga-location="Footer"
                    >
                      Why Credo
                    </a>
                  </li>
  
                  <li id="footlist">
                    <a
                      href="/pages/the-credo-clean-standard"
                      data-ga="The Dirty List®"
                      data-ga-location="Footer"
                    >
                      The Dirty List®
                    </a>
                  </li>
  
                  <li>
                    <a
                      href="https://credobeauty.com/pages/credo-for-change"
                      data-ga="Credo for Change"
                      data-ga-location="Footer"
                    >
                      Credo for Change
                    </a>
                  </li>
  
                  <li id="footlist">
                    <a
                      href="/pages/cruelty-free"
                      data-ga="Cruelty Free"
                      data-ga-location="Footer"
                    >
                      Cruelty Free
                    </a>
                  </li>
  
                  <li id="footlist">
                    <a
                      href="https://credobeauty.com/pages/find-a-store"
                      data-ga="Find a Store"
                      data-ga-location="Footer"
                    >
                      Find a Store
                    </a>
                  </li>
  
                  <li id="footlist">
                    <a
                      href="/blogs/clean-scene"
                      data-ga="Blog"
                      data-ga-location="Footer"
                    >
                      Blog
                    </a>
                  </li>
  
                  <li id="footlist">
                    <a
                      href="/pages/careers"
                      data-ga="Careers"
                      data-ga-location="Footer"
                    >
                      Careers
                    </a>
                  </li>
                </ul>
              </div>
            </div>
  
            <!-- <-----------RESOURCE DIV--------->
            <div class="resource-container" style="max-width: 145px">
              <h2>Resources</h2>
  
              <ul id="footul">
                <li>
                  <a
                    href="https://credobeauty.com/account"
                    data-ga="My Account"
                    data-ga-location="Footer"
                  >
                    My Account
                  </a>
                </li>
  
                <li id="footlist">
                  <a
                    href="https://credobeauty.com/pages/your-product-finder"
                    data-ga="Your Product Finder"
                    data-ga-location="Footer"
                  >
                    Your Product Finder
                  </a>
                </li>
  
                <li id="footlist">
                  <a
                    href="/pages/accessibility"
                    data-ga="Accessibility"
                    data-ga-location="Footer"
                  >
                    Accessibility
                  </a>
                </li>
  
                <li id="footlist">
                  <a
                    href="/pages/terms-of-use"
                    data-ga="Terms of Use"
                    data-ga-location="Footer"
                  >
                    Terms of Use
                  </a>
                </li>
  
                <li id="footlist">
                  <a
                    href="/pages/privacy-policy"
                    data-ga="Privacy Policy"
                    data-ga-location="Footer"
                  >
                    Privacy Policy
                  </a>
                </li>
              </ul>
            </div>
  
            <!-- <------------Discounts------------->
            <div class="Discounts" style="max-width: 145px">
              <h2>Discounts</h2>
  
              <ul id="footul">
                <li id="footlist">
                  <a
                    href="https://credobeauty.com/pages/essential-workers"
                    data-ga="Essential Workers"
                    data-ga-location="Footer"
                  >
                    Essential Workers
                  </a>
                </li>
  
                <li id="footlist">
                  <a
                    href="https://credobeauty.com/pages/refer-a-friend"
                    data-ga="Refer a Friend"
                    data-ga-location="Footer"
                  >
                    Refer a Friend
                  </a>
                </li>
  
                <li id="footlist">
                  <a
                    href="https://credobeauty.com/pages/seniors"
                    data-ga="Seniors"
                    data-ga-location="Footer"
                  >
                    Seniors
                  </a>
                </li>
  
                <li id="footlist">
                  <a
                    href="https://credobeauty.com/pages/student-discount"
                    data-ga="StudentBeans"
                    data-ga-location="Footer"
                  >
                    StudentBeans
                  </a>
                </li>
              </ul>
            </div>
  
            <!-- <---------CONTACTUS---------->
            <div class="CONTACTUS" style="max-width: 145px">
              <h2>CONTACT US</h2>
  
              <ul id="footul">
                <li id="footlist">
                  <a
                    href="/pages/credo-live"
                    data-ga="CredoLive (Chat with us)"
                    data-ga-location="Footer"
                  >
                    CredoLive (Chat with us)
                  </a>
                </li>
  
                <li id="footlist">
                  <a
                    href="https://form.jotform.com/220175845966062"
                    data-ga="Email Us"
                    data-ga-location="Footer"
                  >
                    Email Us
                  </a>
                </li>
  
                <li id="footlist">
                  <a
                    href="/pages/contact-1"
                    data-ga="FAQs"
                    data-ga-location="Footer"
                  >
                    FAQs
                  </a>
                </li>
  
                <li id="footlist">
                  <a
                    href="tel:1-844-692-7336"
                    data-ga="1-844-692-7336"
                    data-ga-location="Footer"
                  >
                    1-844-692-7336
                  </a>
                </li>
              </ul>
            </div>
          </div>
  
          <div id="thirddiv">
            <!-- <---------angels------->
            <div class="lipsici_anglee">
              <p>
                A portion&nbsp;of every purchase made on
                <a href="/pages/home" title="Home">Credo Beauty</a> is donated to
                <a
                  href="https://next-world.myshopify.com/pages/the-lipstick-angels"
                  title="https://next-world.myshopify.com/pages/the-lipstick-angels"
                  >Lipstick Angels</a
                >
              </p>
            </div>
            <div class="footer__payments">
              <ul  id="footer__payments-list">
                <li id="footlist">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    role="img"
                    viewBox="0 0 38 24"
                    width="38"
                    height="24"
                    aria-labelledby="pi-american_express"
                  >
                    <title id="pi-american_express">American Express</title>
                    <g fill="none">
                      <path
                        fill="#000"
                        d="M35,0 L3,0 C1.3,0 0,1.3 0,3 L0,21 C0,22.7 1.4,24 3,24 L35,24 C36.7,24 38,22.7 38,21 L38,3 C38,1.3 36.6,0 35,0 Z"
                        opacity=".07"
                      ></path>
                      <path
                        fill="#006FCF"
                        d="M35,1 C36.1,1 37,1.9 37,3 L37,21 C37,22.1 36.1,23 35,23 L3,23 C1.9,23 1,22.1 1,21 L1,3 C1,1.9 1.9,1 3,1 L35,1"
                      ></path>
                      <path
                        fill="#FFF"
                        d="M8.971,10.268 L9.745,12.144 L8.203,12.144 L8.971,10.268 Z M25.046,10.346 L22.069,10.346 L22.069,11.173 L24.998,11.173 L24.998,12.412 L22.075,12.412 L22.075,13.334 L25.052,13.334 L25.052,14.073 L27.129,11.828 L25.052,9.488 L25.046,10.346 L25.046,10.346 Z M10.983,8.006 L14.978,8.006 L15.865,9.941 L16.687,8 L27.057,8 L28.135,9.19 L29.25,8 L34.013,8 L30.494,11.852 L33.977,15.68 L29.143,15.68 L28.065,14.49 L26.94,15.68 L10.03,15.68 L9.536,14.49 L8.406,14.49 L7.911,15.68 L4,15.68 L7.286,8 L10.716,8 L10.983,8.006 Z M19.646,9.084 L17.407,9.084 L15.907,12.62 L14.282,9.084 L12.06,9.084 L12.06,13.894 L10,9.084 L8.007,9.084 L5.625,14.596 L7.18,14.596 L7.674,13.406 L10.27,13.406 L10.764,14.596 L13.484,14.596 L13.484,10.661 L15.235,14.602 L16.425,14.602 L18.165,10.673 L18.165,14.603 L19.623,14.603 L19.647,9.083 L19.646,9.084 Z M28.986,11.852 L31.517,9.084 L29.695,9.084 L28.094,10.81 L26.546,9.084 L20.652,9.084 L20.652,14.602 L26.462,14.602 L28.076,12.864 L29.624,14.602 L31.499,14.602 L28.987,11.852 L28.986,11.852 Z"
                      ></path>
                    </g>
                  </svg>
                </li>
                <li id="footlist">
                  <svg
                    version="1.1"
                    xmlns="http://www.w3.org/2000/svg"
                    role="img"
                    x="0"
                    y="0"
                    width="38"
                    height="24"
                    viewBox="0 0 165.521 105.965"
                    xml:space="preserve"
                    aria-labelledby="pi-apple_pay"
                  >
                    <title id="pi-apple_pay">Apple Pay</title>
                    <path
                      fill="#000"
                      d="M150.698 0H14.823c-.566 0-1.133 0-1.698.003-.477.004-.953.009-1.43.022-1.039.028-2.087.09-3.113.274a10.51 10.51 0 0 0-2.958.975 9.932 9.932 0 0 0-4.35 4.35 10.463 10.463 0 0 0-.975 2.96C.113 9.611.052 10.658.024 11.696a70.22 70.22 0 0 0-.022 1.43C0 13.69 0 14.256 0 14.823v76.318c0 .567 0 1.132.002 1.699.003.476.009.953.022 1.43.028 1.036.09 2.084.275 3.11a10.46 10.46 0 0 0 .974 2.96 9.897 9.897 0 0 0 1.83 2.52 9.874 9.874 0 0 0 2.52 1.83c.947.483 1.917.79 2.96.977 1.025.183 2.073.245 3.112.273.477.011.953.017 1.43.02.565.004 1.132.004 1.698.004h135.875c.565 0 1.132 0 1.697-.004.476-.002.952-.009 1.431-.02 1.037-.028 2.085-.09 3.113-.273a10.478 10.478 0 0 0 2.958-.977 9.955 9.955 0 0 0 4.35-4.35c.483-.947.789-1.917.974-2.96.186-1.026.246-2.074.274-3.11.013-.477.02-.954.022-1.43.004-.567.004-1.132.004-1.699V14.824c0-.567 0-1.133-.004-1.699a63.067 63.067 0 0 0-.022-1.429c-.028-1.038-.088-2.085-.274-3.112a10.4 10.4 0 0 0-.974-2.96 9.94 9.94 0 0 0-4.35-4.35A10.52 10.52 0 0 0 156.939.3c-1.028-.185-2.076-.246-3.113-.274a71.417 71.417 0 0 0-1.431-.022C151.83 0 151.263 0 150.698 0z"
                    ></path>
                    <path
                      fill="#FFF"
                      d="M150.698 3.532l1.672.003c.452.003.905.008 1.36.02.793.022 1.719.065 2.583.22.75.135 1.38.34 1.984.648a6.392 6.392 0 0 1 2.804 2.807c.306.6.51 1.226.645 1.983.154.854.197 1.783.218 2.58.013.45.019.9.02 1.36.005.557.005 1.113.005 1.671v76.318c0 .558 0 1.114-.004 1.682-.002.45-.008.9-.02 1.35-.022.796-.065 1.725-.221 2.589a6.855 6.855 0 0 1-.645 1.975 6.397 6.397 0 0 1-2.808 2.807c-.6.306-1.228.511-1.971.645-.881.157-1.847.2-2.574.22-.457.01-.912.017-1.379.019-.555.004-1.113.004-1.669.004H14.801c-.55 0-1.1 0-1.66-.004a74.993 74.993 0 0 1-1.35-.018c-.744-.02-1.71-.064-2.584-.22a6.938 6.938 0 0 1-1.986-.65 6.337 6.337 0 0 1-1.622-1.18 6.355 6.355 0 0 1-1.178-1.623 6.935 6.935 0 0 1-.646-1.985c-.156-.863-.2-1.788-.22-2.578a66.088 66.088 0 0 1-.02-1.355l-.003-1.327V14.474l.002-1.325a66.7 66.7 0 0 1 .02-1.357c.022-.792.065-1.717.222-2.587a6.924 6.924 0 0 1 .646-1.981c.304-.598.7-1.144 1.18-1.623a6.386 6.386 0 0 1 1.624-1.18 6.96 6.96 0 0 1 1.98-.646c.865-.155 1.792-.198 2.586-.22.452-.012.905-.017 1.354-.02l1.677-.003h135.875"
                    ></path>
                    <g>
                      <g>
                        <path
                          fill="#000"
                          d="M43.508 35.77c1.404-1.755 2.356-4.112 2.105-6.52-2.054.102-4.56 1.355-6.012 3.112-1.303 1.504-2.456 3.959-2.156 6.266 2.306.2 4.61-1.152 6.063-2.858"
                        ></path>
                        <path
                          fill="#000"
                          d="M45.587 39.079c-3.35-.2-6.196 1.9-7.795 1.9-1.6 0-4.049-1.8-6.698-1.751-3.447.05-6.645 2-8.395 5.1-3.598 6.2-.95 15.4 2.55 20.45 1.699 2.5 3.747 5.25 6.445 5.151 2.55-.1 3.549-1.65 6.647-1.65 3.097 0 3.997 1.65 6.696 1.6 2.798-.05 4.548-2.5 6.247-5 1.95-2.85 2.747-5.6 2.797-5.75-.05-.05-5.396-2.101-5.446-8.251-.05-5.15 4.198-7.6 4.398-7.751-2.399-3.548-6.147-3.948-7.447-4.048"
                        ></path>
                      </g>
                      <g>
                        <path
                          fill="#000"
                          d="M78.973 32.11c7.278 0 12.347 5.017 12.347 12.321 0 7.33-5.173 12.373-12.529 12.373h-8.058V69.62h-5.822V32.11h14.062zm-8.24 19.807h6.68c5.07 0 7.954-2.729 7.954-7.46 0-4.73-2.885-7.434-7.928-7.434h-6.706v14.894z"
                        ></path>
                        <path
                          fill="#000"
                          d="M92.764 61.847c0-4.809 3.665-7.564 10.423-7.98l7.252-.442v-2.08c0-3.04-2.001-4.704-5.562-4.704-2.938 0-5.07 1.507-5.51 3.82h-5.252c.157-4.86 4.731-8.395 10.918-8.395 6.654 0 10.995 3.483 10.995 8.89v18.663h-5.38v-4.497h-.13c-1.534 2.937-4.914 4.782-8.579 4.782-5.406 0-9.175-3.222-9.175-8.057zm17.675-2.417v-2.106l-6.472.416c-3.64.234-5.536 1.585-5.536 3.95 0 2.288 1.975 3.77 5.068 3.77 3.95 0 6.94-2.522 6.94-6.03z"
                        ></path>
                        <path
                          fill="#000"
                          d="M120.975 79.652v-4.496c.364.051 1.247.103 1.715.103 2.573 0 4.029-1.09 4.913-3.899l.52-1.663-9.852-27.293h6.082l6.863 22.146h.13l6.862-22.146h5.927l-10.216 28.67c-2.34 6.577-5.017 8.735-10.683 8.735-.442 0-1.872-.052-2.261-.157z"
                        ></path>
                      </g>
                    </g>
                  </svg>
                </li>
                <li id="footlist">
                  <svg
                    viewBox="0 0 38 24"
                    width="38"
                    height="24"
                    role="img"
                    aria-labelledby="pi-discover"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <title id="pi-discover">Discover</title>
                    <path
                      fill="#000"
                      opacity=".07"
                      d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"
                    ></path>
                    <path
                      d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32z"
                      fill="#fff"
                    ></path>
                    <path
                      d="M3.57 7.16H2v5.5h1.57c.83 0 1.43-.2 1.96-.63.63-.52 1-1.3 1-2.11-.01-1.63-1.22-2.76-2.96-2.76zm1.26 4.14c-.34.3-.77.44-1.47.44h-.29V8.1h.29c.69 0 1.11.12 1.47.44.37.33.59.84.59 1.37 0 .53-.22 1.06-.59 1.39zm2.19-4.14h1.07v5.5H7.02v-5.5zm3.69 2.11c-.64-.24-.83-.4-.83-.69 0-.35.34-.61.8-.61.32 0 .59.13.86.45l.56-.73c-.46-.4-1.01-.61-1.62-.61-.97 0-1.72.68-1.72 1.58 0 .76.35 1.15 1.35 1.51.42.15.63.25.74.31.21.14.32.34.32.57 0 .45-.35.78-.83.78-.51 0-.92-.26-1.17-.73l-.69.67c.49.73 1.09 1.05 1.9 1.05 1.11 0 1.9-.74 1.9-1.81.02-.89-.35-1.29-1.57-1.74zm1.92.65c0 1.62 1.27 2.87 2.9 2.87.46 0 .86-.09 1.34-.32v-1.26c-.43.43-.81.6-1.29.6-1.08 0-1.85-.78-1.85-1.9 0-1.06.79-1.89 1.8-1.89.51 0 .9.18 1.34.62V7.38c-.47-.24-.86-.34-1.32-.34-1.61 0-2.92 1.28-2.92 2.88zm12.76.94l-1.47-3.7h-1.17l2.33 5.64h.58l2.37-5.64h-1.16l-1.48 3.7zm3.13 1.8h3.04v-.93h-1.97v-1.48h1.9v-.93h-1.9V8.1h1.97v-.94h-3.04v5.5zm7.29-3.87c0-1.03-.71-1.62-1.95-1.62h-1.59v5.5h1.07v-2.21h.14l1.48 2.21h1.32l-1.73-2.32c.81-.17 1.26-.72 1.26-1.56zm-2.16.91h-.31V8.03h.33c.67 0 1.03.28 1.03.82 0 .55-.36.85-1.05.85z"
                      fill="#231F20"
                    ></path>
                    <path
                      d="M20.16 12.86a2.931 2.931 0 100-5.862 2.931 2.931 0 000 5.862z"
                      fill="url(#pi-paint0_linear)"
                    ></path>
                    <path
                      opacity=".65"
                      d="M20.16 12.86a2.931 2.931 0 100-5.862 2.931 2.931 0 000 5.862z"
                      fill="url(#pi-paint1_linear)"
                    ></path>
                    <path
                      d="M36.57 7.506c0-.1-.07-.15-.18-.15h-.16v.48h.12v-.19l.14.19h.14l-.16-.2c.06-.01.1-.06.1-.13zm-.2.07h-.02v-.13h.02c.06 0 .09.02.09.06 0 .05-.03.07-.09.07z"
                      fill="#231F20"
                    ></path>
                    <path
                      d="M36.41 7.176c-.23 0-.42.19-.42.42 0 .23.19.42.42.42.23 0 .42-.19.42-.42 0-.23-.19-.42-.42-.42zm0 .77c-.18 0-.34-.15-.34-.35 0-.19.15-.35.34-.35.18 0 .33.16.33.35 0 .19-.15.35-.33.35z"
                      fill="#231F20"
                    ></path>
                    <path
                      d="M37 12.984S27.09 19.873 8.976 23h26.023a2 2 0 002-1.984l.024-3.02L37 12.985z"
                      fill="#F48120"
                    ></path>
                    <defs>
                      <linearGradient
                        id="pi-paint0_linear"
                        x1="21.657"
                        y1="12.275"
                        x2="19.632"
                        y2="9.104"
                        gradientUnits="userSpaceOnUse"
                      >
                        <stop stop-color="#F89F20"></stop>
                        <stop offset=".25" stop-color="#F79A20"></stop>
                        <stop offset=".533" stop-color="#F68D20"></stop>
                        <stop offset=".62" stop-color="#F58720"></stop>
                        <stop offset=".723" stop-color="#F48120"></stop>
                        <stop offset="1" stop-color="#F37521"></stop>
                      </linearGradient>
                      <linearGradient
                        id="pi-paint1_linear"
                        x1="21.338"
                        y1="12.232"
                        x2="18.378"
                        y2="6.446"
                        gradientUnits="userSpaceOnUse"
                      >
                        <stop stop-color="#F58720"></stop>
                        <stop offset=".359" stop-color="#E16F27"></stop>
                        <stop offset=".703" stop-color="#D4602C"></stop>
                        <stop offset=".982" stop-color="#D05B2E"></stop>
                      </linearGradient>
                    </defs>
                  </svg>
                </li>
                <li id="footlist">
                  <svg
                    viewBox="0 0 38 24"
                    xmlns="http://www.w3.org/2000/svg"
                    role="img"
                    width="38"
                    height="24"
                    aria-labelledby="pi-master"
                  >
                    <title id="pi-master">Mastercard</title>
                    <path
                      opacity=".07"
                      d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"
                    ></path>
                    <path
                      fill="#fff"
                      d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"
                    ></path>
                    <circle fill="#EB001B" cx="15" cy="12" r="7"></circle>
                    <circle fill="#F79E1B" cx="23" cy="12" r="7"></circle>
                    <path
                      fill="#FF5F00"
                      d="M22 12c0-2.4-1.2-4.5-3-5.7-1.8 1.3-3 3.4-3 5.7s1.2 4.5 3 5.7c1.8-1.2 3-3.3 3-5.7z"
                    ></path>
                  </svg>
                </li>
                <li id="footlist">
                  <svg
                    viewBox="0 0 38 24"
                    xmlns="http://www.w3.org/2000/svg"
                    width="38"
                    height="24"
                    role="img"
                    aria-labelledby="pi-paypal"
                  >
                    <title id="pi-paypal">PayPal</title>
                    <path
                      opacity=".07"
                      d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"
                    ></path>
                    <path
                      fill="#fff"
                      d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"
                    ></path>
                    <path
                      fill="#003087"
                      d="M23.9 8.3c.2-1 0-1.7-.6-2.3-.6-.7-1.7-1-3.1-1h-4.1c-.3 0-.5.2-.6.5L14 15.6c0 .2.1.4.3.4H17l.4-3.4 1.8-2.2 4.7-2.1z"
                    ></path>
                    <path
                      fill="#3086C8"
                      d="M23.9 8.3l-.2.2c-.5 2.8-2.2 3.8-4.6 3.8H18c-.3 0-.5.2-.6.5l-.6 3.9-.2 1c0 .2.1.4.3.4H19c.3 0 .5-.2.5-.4v-.1l.4-2.4v-.1c0-.2.3-.4.5-.4h.3c2.1 0 3.7-.8 4.1-3.2.2-1 .1-1.8-.4-2.4-.1-.5-.3-.7-.5-.8z"
                    ></path>
                    <path
                      fill="#012169"
                      d="M23.3 8.1c-.1-.1-.2-.1-.3-.1-.1 0-.2 0-.3-.1-.3-.1-.7-.1-1.1-.1h-3c-.1 0-.2 0-.2.1-.2.1-.3.2-.3.4l-.7 4.4v.1c0-.3.3-.5.6-.5h1.3c2.5 0 4.1-1 4.6-3.8v-.2c-.1-.1-.3-.2-.5-.2h-.1z"
                    ></path>
                  </svg>
                </li>
                <li id="footlist">
                  <svg
                    viewBox="0 0 38 24"
                    width="38"
                    height="24"
                    xmlns="http://www.w3.org/2000/svg"
                    role="img"
                    aria-labelledby="pi-venmo"
                  >
                    <title id="pi-venmo">Venmo</title>
                    <g fill="none" fill-rule="evenodd">
                      <rect
                        fill-opacity=".07"
                        fill="#000"
                        width="38"
                        height="24"
                        rx="3"
                      ></rect>
                      <path
                        fill="#3D95CE"
                        d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"
                      ></path>
                      <path
                        d="M24.675 8.36c0 3.064-2.557 7.045-4.633 9.84h-4.74L13.4 6.57l4.151-.402 1.005 8.275c.94-1.566 2.099-4.025 2.099-5.702 0-.918-.154-1.543-.394-2.058l3.78-.783c.437.738.634 1.499.634 2.46z"
                        fill="#FFF"
                        fill-rule="nonzero"
                      ></path>
                    </g>
                  </svg>
                </li>
                <li id="footlist">
                  <svg
                    viewBox="0 0 38 24"
                    xmlns="http://www.w3.org/2000/svg"
                    role="img"
                    width="38"
                    height="24"
                    aria-labelledby="pi-visa"
                  >
                    <title id="pi-visa">Visa</title>
                    <path
                      opacity=".07"
                      d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.4 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.4-3-3-3z"
                    ></path>
                    <path
                      fill="#fff"
                      d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32"
                    ></path>
                    <path
                      d="M28.3 10.1H28c-.4 1-.7 1.5-1 3h1.9c-.3-1.5-.3-2.2-.6-3zm2.9 5.9h-1.7c-.1 0-.1 0-.2-.1l-.2-.9-.1-.2h-2.4c-.1 0-.2 0-.2.2l-.3.9c0 .1-.1.1-.1.1h-2.1l.2-.5L27 8.7c0-.5.3-.7.8-.7h1.5c.1 0 .2 0 .2.2l1.4 6.5c.1.4.2.7.2 1.1.1.1.1.1.1.2zm-13.4-.3l.4-1.8c.1 0 .2.1.2.1.7.3 1.4.5 2.1.4.2 0 .5-.1.7-.2.5-.2.5-.7.1-1.1-.2-.2-.5-.3-.8-.5-.4-.2-.8-.4-1.1-.7-1.2-1-.8-2.4-.1-3.1.6-.4.9-.8 1.7-.8 1.2 0 2.5 0 3.1.2h.1c-.1.6-.2 1.1-.4 1.7-.5-.2-1-.4-1.5-.4-.3 0-.6 0-.9.1-.2 0-.3.1-.4.2-.2.2-.2.5 0 .7l.5.4c.4.2.8.4 1.1.6.5.3 1 .8 1.1 1.4.2.9-.1 1.7-.9 2.3-.5.4-.7.6-1.4.6-1.4 0-2.5.1-3.4-.2-.1.2-.1.2-.2.1zm-3.5.3c.1-.7.1-.7.2-1 .5-2.2 1-4.5 1.4-6.7.1-.2.1-.3.3-.3H18c-.2 1.2-.4 2.1-.7 3.2-.3 1.5-.6 3-1 4.5 0 .2-.1.2-.3.2M5 8.2c0-.1.2-.2.3-.2h3.4c.5 0 .9.3 1 .8l.9 4.4c0 .1 0 .1.1.2 0-.1.1-.1.1-.1l2.1-5.1c-.1-.1 0-.2.1-.2h2.1c0 .1 0 .1-.1.2l-3.1 7.3c-.1.2-.1.3-.2.4-.1.1-.3 0-.5 0H9.7c-.1 0-.2 0-.2-.2L7.9 9.5c-.2-.2-.5-.5-.9-.6-.6-.3-1.7-.5-1.9-.5L5 8.2z"
                      fill="#142688"
                    ></path>
                  </svg>
                </li>
              </ul>
            </div>
          </div>
        </div>
    </div>
     `
}

export default footer;